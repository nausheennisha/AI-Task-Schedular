from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
from sklearn.linear_model import LinearRegression

app = Flask(__name__)
CORS(app)

@app.route("/schedule", methods=["POST"])
def schedule():
    data = request.json
    df = pd.DataFrame(data)

    model = LinearRegression()
    model.fit(df[['Prev_Burst']], df['Prev_Burst'] * 0.9)

    schedule_log = []
    ready_queue = []
    time_now = 0
    entered = set()
    processes = df.to_dict(orient="records")

    while len(schedule_log) < len(processes):
        for proc in processes:
            if proc["Arrival"] <= time_now and proc["PID"] not in entered:
                predicted = model.predict([[proc["Prev_Burst"]]])[0]
                proc["Predicted_Burst"] = round(predicted, 2)
                ready_queue.append(proc)
                entered.add(proc["PID"])
        if ready_queue:
            ready_queue.sort(key=lambda x: x["Predicted_Burst"])
            current = ready_queue.pop(0)
            start = time_now
            end = start + current["Predicted_Burst"]
            time_now = end
            schedule_log.append({
                "PID": current["PID"],
                "Task": current["Task_Name"],
                "Start": round(start, 2),
                "End": round(end, 2),
                "Predicted": round(current["Predicted_Burst"], 2)
            })
        else:
            time_now += 1

    return jsonify(schedule_log)

if __name__ == "__main__":
    app.run(debug=True)


from flask import render_template

@app.route('/')
def index():
    return render_template('index.html')
