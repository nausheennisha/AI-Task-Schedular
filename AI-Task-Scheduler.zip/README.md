# AI Task Scheduler

A lightweight task scheduler using Machine Learning (Linear Regression) to predict burst times and dynamically order tasks using Shortest Job First logic.

## Features
- Predicts CPU burst using `LinearRegression`
- Dynamically builds ready queue
- Built with Flask and Scikit-learn
- Returns JSON with task execution logs

## Run Locally
```bash
pip install -r requirements.txt
python app.py
```

## API Endpoint
`POST /schedule` with JSON body like:
```json
[
  {"PID": 1, "Task_Name": "Chrome", "Arrival": 0, "Prev_Burst": 4.0},
  {"PID": 2, "Task_Name": "VSCode", "Arrival": 1, "Prev_Burst": 3.0}
]
```

Returns scheduled task timings.
